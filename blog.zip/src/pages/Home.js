import React from 'react'
import Articles from '../components/Articles'

const Home = () => {
  return (
    <>
    <Articles />
    </>
  )
}

export default Home