import React from 'react'

const Bussines = () => {
  return (
    <div>Bussines</div>
  )
}

export default Bussines